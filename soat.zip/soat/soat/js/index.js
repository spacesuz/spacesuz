var hourOnesRing = document.querySelector('#hour-ones');
var minuteTensRing = document.querySelector('#minute-tens');
var minuteOnesRing = document.querySelector('#minute-ones');

var resetRing = function resetRing(event) {
  if (event.target.style.transform === 'rotate(-180deg)') {
    event.target.style.transition = 'none';
    event.target.style.transform = 'rotate(180deg)';
  }
};

var updateRing = function updateRing(ring, rotate) {
  if (ring.style.transition.startsWith('none')) {
    ring.style.transition = null;
  }

  if (rotate === 'rotate(180deg)' && ring.style.transform !== 'rotate(180deg)') {
    ring.style.transform = 'rotate(-180deg)';
  } else {
    ring.style.transform = rotate;
  }
};

hourOnesRing.addEventListener('transitionend', resetRing);
minuteTensRing.addEventListener('transitionend', resetRing);
minuteOnesRing.addEventListener('transitionend', resetRing);

var faster = document.querySelector('#faster');

var update = function update() {
  var now = new Date();

  var hours = faster.checked ? now.getMinutes() : now.getHours();
  var minutes = faster.checked ? now.getSeconds() : now.getMinutes();

  var hoursTwelves = Math.floor(hours % 12);
  var minuteTens = Math.floor(minutes / 10) + 6 * (hours % 2);
  var minuteOnes = minutes % 10;

  updateRing(hourOnesRing, 'rotate(' + (180 - 30 * hoursTwelves) + 'deg)');
  updateRing(minuteTensRing, 'rotate(' + (180 - 30 * minuteTens) + 'deg)');
  updateRing(minuteOnesRing, 'rotate(' + (180 - 36 * minuteOnes) + 'deg)');
};

update();

hourOnesRing.style.transition = 'none';
minuteTensRing.style.transition = 'none';
minuteOnesRing.style.transition = 'none';

window.setInterval(update, 1000);

// Fix for Firefox and Safari
if (!navigator.userAgent.includes('Chrome')) {
  document.querySelectorAll('feImage[*|href^="#"]').forEach(function (feImage) {
    var href = feImage.getAttribute('xlink:href');
    var svg = '<svg viewBox="0 0 300 300" width="300" height="300" xmlns="http://www.w3.org/2000/svg">' + document.querySelector(href).outerHTML + '</svg>';
    var dataUri = 'data:image/svg+xml;base64,' + window.btoa(svg);
    feImage.setAttribute('xlink:href', dataUri);
  });
}